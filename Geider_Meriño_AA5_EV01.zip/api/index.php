<?php
// Configuración de cabeceras para permitir solicitudes desde otros dominios (CORS).
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");

// Conexión a la base de datos
$servername = "localhost"; // Servidor local
$username = "root";        // Usuario de MySQL por defecto
$password = "";            // Contraseña vacía por defecto
$dbname = "api_users";     // Nombre de la base de datos

try {
    // Crear la conexión
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Configurar modo de errores
} catch (PDOException $e) {
    echo json_encode(["message" => "Error al conectar con la base de datos"]);
    exit;
}

// Leer datos enviados por el cliente
$data = json_decode(file_get_contents("php://input"));

// Validar que los datos sean correctos
if (!isset($data->action)) {
    echo json_encode(["message" => "No se especificó la acción."]);
    exit;
}

// Registro de usuarios
if ($data->action == "register") {
    if (!empty($data->username) && !empty($data->password)) {
        // Encriptar contraseña
        $hashedPassword = password_hash($data->password, PASSWORD_BCRYPT);

        // Insertar usuario en la base de datos
        $sql = "INSERT INTO users (username, password) VALUES (:username, :password)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':username', $data->username);
        $stmt->bindParam(':password', $hashedPassword);

        try {
            $stmt->execute();
            echo json_encode(["message" => "Registro exitoso"]);
        } catch (PDOException $e) {
            echo json_encode(["message" => "Error: " . $e->getMessage()]);
        }
    } else {
        echo json_encode(["message" => "Faltan datos para el registro"]);
    }
}

// Inicio de sesión
if ($data->action == "login") {
    if (!empty($data->username) && !empty($data->password)) {
        // Buscar usuario en la base de datos
        $sql = "SELECT * FROM users WHERE username = :username";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':username', $data->username);
        $stmt->execute();
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($data->password, $user['password'])) {
            // Contraseña correcta
            echo json_encode(["message" => "Autenticación satisfactoria"]);
        } else {
            // Contraseña incorrecta
            echo json_encode(["message" => "Error en la autenticación"]);
        }
    } else {
        echo json_encode(["message" => "Faltan datos para el inicio de sesión"]);
    }
}
?>